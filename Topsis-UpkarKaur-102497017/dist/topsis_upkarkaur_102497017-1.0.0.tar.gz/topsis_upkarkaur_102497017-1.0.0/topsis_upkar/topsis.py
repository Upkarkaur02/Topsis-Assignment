import sys
import pandas as pd
import numpy as np

def calculate_topsis(input_file, weights, impacts, output_file):

    try:
        data = pd.read_csv(input_file)
    except FileNotFoundError:
        print("Error: File not found.")
        sys.exit(1)

    if data.shape[1] < 3:
        print("Error: Input file must contain three or more columns.")
        sys.exit(1)

    numeric_data = data.iloc[:, 1:]

    if not np.issubdtype(numeric_data.values.dtype, np.number):
        print("Error: Columns from 2nd to last must contain numeric values only.")
        sys.exit(1)

    weights = weights.split(',')
    impacts = impacts.split(',')

    if len(weights) != len(impacts) or len(weights) != numeric_data.shape[1]:
        print("Error: Number of weights, impacts and columns must be same.")
        sys.exit(1)

    for impact in impacts:
        if impact not in ['+', '-']:
            print("Error: Impacts must be either '+' or '-'.")
            sys.exit(1)

    weights = np.array(weights, dtype=float)

    norm = numeric_data / np.sqrt((numeric_data**2).sum())
    weighted = norm * weights

    ideal_best = []
    ideal_worst = []

    for i in range(len(impacts)):
        if impacts[i] == '+':
            ideal_best.append(weighted.iloc[:, i].max())
            ideal_worst.append(weighted.iloc[:, i].min())
        else:
            ideal_best.append(weighted.iloc[:, i].min())
            ideal_worst.append(weighted.iloc[:, i].max())

    ideal_best = np.array(ideal_best)
    ideal_worst = np.array(ideal_worst)

    s_best = np.sqrt(((weighted - ideal_best) ** 2).sum(axis=1))
    s_worst = np.sqrt(((weighted - ideal_worst) ** 2).sum(axis=1))

    score = s_worst / (s_best + s_worst)

    data['Topsis Score'] = score
    data['Rank'] = score.rank(ascending=False)

    data.to_csv(output_file, index=False)
    print("Result successfully written to", output_file)


def main():
    if len(sys.argv) != 5:
        print("Usage: topsis <InputFile> <Weights> <Impacts> <OutputFile>")
        sys.exit(1)

    input_file = sys.argv[1]
    weights = sys.argv[2]
    impacts = sys.argv[3]
    output_file = sys.argv[4]

    calculate_topsis(input_file, weights, impacts, output_file)
