# Topsis-UpkarKaur-102497017

Python implementation of TOPSIS method.

## Installation

pip install Topsis-UpkarKaur-102497017

## Usage

topsis data.csv 1,1,1,2 +,+,-,+ result.csv

## Requirements
- Python >= 3.6
- pandas
- numpy
